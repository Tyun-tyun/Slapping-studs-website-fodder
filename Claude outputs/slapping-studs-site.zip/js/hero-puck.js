/* hero-puck.js - fits the fixed 1440x900 hero scene to the hero box,
   writes the current year on the puck, and wires the Replay button. */
(function(){
"use strict";
var hp=document.getElementById('hp'); if(!hp) return;
var hero=hp.parentNode;
var yr=document.getElementById('hpYear'); if(yr) yr.textContent=String(new Date().getFullYear());
function fit(){
  var w=hero.clientWidth,h=hero.clientHeight;
  hp.style.setProperty('--hp-s',Math.max(w/1440,h/900).toFixed(4));
}
fit();
if(window.ResizeObserver) new ResizeObserver(fit).observe(hero); else window.addEventListener('resize',fit);
var els=hp.querySelectorAll('.hp-cam,.hp-dropper,.hp-puck,.hp-face,.hp-rg,.hp-pn,.hp-sh,.hp-pra,.hp-prb');
var btn=document.getElementById('hpReplay');
if(btn) btn.addEventListener('click',function(){
  for(var i=0;i<els.length;i++) els[i].style.animation='none';
  void hp.offsetWidth;
  for(var k=0;k<els.length;k++) els[k].style.animation='';
});
})();
